char getprintablechar(char a);
int is_printable (int c);
void dump_bytes(unsigned char *buf, int len);
